var express = require('express');
var router = express.Router();
const db = require("../db");
/* GET home page. */
router.get('/', async (req, res, next) => {
  const result = await db.find();
  res.render('index', { title: 'CRUD', result});
});
router.post("/save", async (req, res, next) => {
  const customer = req.body;
  const result = await db.insert(customer);
  console.log(result);
  res.json(result);
})

router.post("/delete", async (req, res) => {

    const customerId = req.body.id; // Use customerId para obter o ID do corpo da solicitação
    const result = await db.remove(customerId); // Use customerId ao chamar a função de remoção no banco de dados
    console.log(result);
    res.json(result);
  
})

router.post("/edit", async (req, res) => {
    const customerId = req.body.id; // Use customerId para obter o ID do corpo da solicitação
    const name = req.body.name;
    const result = await db.update(customerId, name); // Use customerId ao chamar a função de atualização no banco de dados
    console.log(result);
    res.json(result);
})

module.exports = router;
